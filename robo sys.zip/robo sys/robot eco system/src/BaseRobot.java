public abstract class BaseRobot implements Robot 
{
    String name;
    double batteryLevel;
    boolean running;

    BaseRobot(String name, double batteryLevel) 
    {
        this.name = name;
        this.batteryLevel = batteryLevel;
        this.running = false;
    }

    public void move(double speed) 
    {
        System.out.println(name + " moves at " + speed + " m/s");
        batteryLevel = batteryLevel - 2;
    }

    public void move(double speed, String direction) 
    {
        System.out.println(name + " moves " + direction + " at " + speed + " m/s");
        batteryLevel = batteryLevel - 3;
    }

    public void start() throws BatteryLowException 
    {
        if (batteryLevel < 15) {
            throw new BatteryLowException(name + " battery is too low to start");
        }

        running = true;
        System.out.println(name + " started");
    }

    public void stop() 
    {
        running = false;
        System.out.println(name + " stopped");
    }

    public String status() 
    {
        return name + " is " + (running ? "running" : "idle") + " with battery " + batteryLevel + "%";
    }
}
