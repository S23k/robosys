import java.util.ArrayList;

public class RobotController 
{
    ArrayList<Robot> robots = new ArrayList<>();

    public void addRobot(Robot robot) 
    {
        robots.add(robot);
    }

    public void issueCommand(String robotName, String command) 
    {
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);

            if (robot instanceof BaseRobot) 
            {
                BaseRobot baseRobot = (BaseRobot) robot;

                if (baseRobot.name.equals(robotName)) {
                    if (command.equals("start")) 
                    {
                        try {
                            robot.start();
                        } catch (BatteryLowException e) {
                            System.out.println(e.getMessage());
                        }
                    } 
                    else if (command.equals("stop")) 
                    {
                        robot.stop();
                    } 
                    else if (command.equals("move")) 
                    {
                        baseRobot.move(5.0, "forward");
                    } 
                    else if (command.equals("fly")) 
                    {
                        if (robot instanceof FlyingRobot) {
                            ((FlyingRobot) robot).fly();
                        } else {
                            System.out.println(robotName + " cannot fly");
                        }
                    } else if (command.equals("drive")) 
                    {
                        if (robot instanceof MovingRobot) {
                            ((MovingRobot) robot).drive(7.0, "east");
                        } else {
                            System.out.println(robotName + " cannot drive");
                        }
                    } 
                    else if (command.equals("walk")) 
                    {
                        if (robot instanceof WalkingRobot) {
                            ((WalkingRobot) robot).walk(10, "north");
                        } else {
                            System.out.println(robotName + " cannot walk");
                        }
                    } 
                    else 
                    {
                        System.out.println("Unknown command: " + command);
                    }

                    return;
                }
            }
        }

        System.out.println("Robot " + robotName + " not found");
    }
}
