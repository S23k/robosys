public class MovingRobot extends BaseRobot 
{
    public MovingRobot(String name, double batteryLevel) 
    {
        super(name, batteryLevel);
    }

    public void drive() 
    {
        System.out.println(name + " is driving");
        batteryLevel = batteryLevel - 4;
    }

    public void drive(double speed, String direction) 
    {
        System.out.println(name + " drives " + direction + " at " + speed );
        batteryLevel = batteryLevel - 5;
    }
}
