public class WalkingRobot extends BaseRobot 
{
    public WalkingRobot(String name, double batteryLevel) 
    {
        super(name, batteryLevel);
    }

    public void walk() 
    {
        System.out.println(name + " is walking");
        batteryLevel = batteryLevel - 3;
    }

    public void walk(int steps, String direction) 
    {
        System.out.println(name + " crawling " + steps + " steps " + direction);
        batteryLevel = batteryLevel - 4;
    }
}
