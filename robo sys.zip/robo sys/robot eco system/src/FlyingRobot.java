public class FlyingRobot extends BaseRobot 
{
    public FlyingRobot(String name, double batteryLevel) 
    {
        super(name, batteryLevel);
    }

    public void fly() 
    {
        System.out.println(name + " is flying");
        batteryLevel = batteryLevel - 5;
    }

    public void fly(double altitude) 
    {
        System.out.println(name + " is flying at altitude " + altitude );
        batteryLevel = batteryLevel - 6;
    }
}
