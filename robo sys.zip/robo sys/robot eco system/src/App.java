import java.util.Scanner;

public class App 
{
    public static void main(String[] args) 
    {
        FlyingRobot drone = new FlyingRobot("Drone", 80);
        MovingRobot rover = new MovingRobot("Rover", 50);
        WalkingRobot walker = new WalkingRobot("Walker", 70);

        RobotController controller = new RobotController();
        controller.addRobot(drone);
        controller.addRobot(rover);
        controller.addRobot(walker);

        Scanner input = new Scanner(System.in);

        while (true) 
        {
            System.out.println();
            System.out.println("Choose a robot:");
            System.out.println("1. Drone");
            System.out.println("2. Rover");
            System.out.println("3. Walker");
            System.out.println("4. Exit");
            System.out.print("Pick a number: ");

            int choice = input.nextInt();

            if (choice == 4) 
            {
                System.out.println("Goodbye!");
                break;
            }

            String selectedRobot = "";
            if (choice == 1) 
            {
                selectedRobot = "Drone";
            } 
            else if (choice == 2) 
            {
                selectedRobot = "Rover";
            } 
            else if (choice == 3) 
            {
                selectedRobot = "Walker";
            } 
            else 
            {
                System.out.println("Invalid choice");
                continue;
            }

            System.out.println();
            System.out.println("What do you want to do with " + selectedRobot + "?");
            System.out.println("1. Start");
            System.out.println("2. Stop");
            System.out.println("3. Fly / Drive / Walk");
            System.out.println("4. Status");
            System.out.print("Choose action: ");

            int action = input.nextInt();

            if (action == 1) 
            {
                controller.issueCommand(selectedRobot, "start");
            } 
            else if (action == 2) 
            {
                controller.issueCommand(selectedRobot, "stop");
            } 
            else if (action == 3) 
            {
                if (selectedRobot.equals("Drone")) {
                    drone.fly();
                } else if (selectedRobot.equals("Rover")) {
                    rover.drive();
                } else if (selectedRobot.equals("Walker")) {
                    walker.walk();
                }
            } 
            else if (action == 4) 
            {
                if (selectedRobot.equals("Drone")) {
                    System.out.println(drone.status());
                } else if (selectedRobot.equals("Rover")) {
                    System.out.println(rover.status());
                } else if (selectedRobot.equals("Walker")) {
                    System.out.println(walker.status());
                }
            } 
            else 
            {
                System.out.println("Invalid action");
            }
        }

        input.close();
    }
}

